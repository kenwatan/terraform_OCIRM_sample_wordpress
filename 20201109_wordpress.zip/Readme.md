Terraform (OCI Resource Manager)を使って
- VCN
- Compute インスタンス
- MySQL Database Service
を作り、Wordpress環境を構築するスクリプト

- ロードバランサー
- 予約済みパブリックIPアドレス
も使用
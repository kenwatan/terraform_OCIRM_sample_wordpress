create user wp identified by 'hogeHoge@Hog123';
grant all privileges on wordpress.* to wp;
exit
